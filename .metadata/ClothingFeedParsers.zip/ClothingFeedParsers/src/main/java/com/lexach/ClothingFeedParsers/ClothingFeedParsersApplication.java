package com.lexach.ClothingFeedParsers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClothingFeedParsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClothingFeedParsersApplication.class, args);
	}
}
